<?php
session_start();

// Подключение к базе данных
$link = mysqli_connect("localhost", "admin", "admin", "test");

if (!$link) {
    die("Connection failed: " . mysqli_connect_error());
}

// Проверяем, передан ли id товара для добавления в корзину
if (isset($_GET['action']) && $_GET['action'] === 'add' && isset($_GET['id'])) {
    $productId = $_GET['id'];
    $userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;

    // Проверяем, есть ли уже товар с таким id в корзине пользователя
    $checkQuery = "SELECT * FROM basket WHERE user_id = ? AND product_id = ?";
    $checkStmt = mysqli_prepare($link, $checkQuery);
    mysqli_stmt_bind_param($checkStmt, "ii", $userId, $productId);
    mysqli_stmt_execute($checkStmt);
    $checkResult = mysqli_stmt_get_result($checkStmt);

    if (!$checkResult) {
        die("Error checking product in basket: " . mysqli_error($link));
    }

    if (mysqli_num_rows($checkResult) == 0) {
        // Товара с таким id еще нет в корзине пользователя, добавляем его
        $insertQuery = "INSERT INTO basket (user_id, product_id, quantity) VALUES (?, ?, 1)";
        $insertStmt = mysqli_prepare($link, $insertQuery);
        mysqli_stmt_bind_param($insertStmt, "ii", $userId, $productId);
        mysqli_stmt_execute($insertStmt);

        if (!$insertStmt) {
            die("Error adding product to basket: " . mysqli_error($link));
        }
    } else {
        // Уже есть в корзине, увеличиваем количество на 1
        $updateQuery = "UPDATE basket SET quantity = quantity + 1 WHERE user_id = ? AND product_id = ?";
        $updateStmt = mysqli_prepare($link, $updateQuery);
        mysqli_stmt_bind_param($updateStmt, "ii", $userId, $productId);
        mysqli_stmt_execute($updateStmt);

        if (!$updateStmt) {
            die("Error updating quantity in basket: " . mysqli_error($link));
        }
    }
}

// Получение товаров из корзины
$selectQuery = "SELECT products.*, basket.quantity FROM basket
                INNER JOIN products ON basket.product_id = products.id
                WHERE basket.user_id = ?";
$stmt = mysqli_prepare($link, $selectQuery);
mysqli_stmt_bind_param($stmt, "i", $userId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (!$result) {
    die("Error fetching products from basket: " . mysqli_error($link));
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Ваш сайт</title>
    <!-- Ваши стили и внешние библиотеки CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-ZdLzUzq+J3GiJXEe4TA6v9v8Z/Qa8CfmQYEWDq1TpJ3cMpw3g8ZmmN/2OgqjeiQRbLzA0cGOT4n7Fp2EAyfETg==" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
        /* Ваши стили */
        body {
            background-color: #343a40;
            color: #ffffff;
        }

        header {
            background-color: #212529;
        }

        header img {
            max-width: 100%;
        }

        header .nav-link {
            color: #ffffff;
        }

        header .btn-light {
            color: #fff;
            background-color: #343a40;
        }

        header .btn-light:hover {
            background-color: #f8f9fa;
        }

        .container {
            margin-top: 20px;
        }

        footer {
            background-color: #212529;
            color: #ffffff;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

        .divider-top {
            border-bottom: 5px solid #dc3545;
            margin-top: 20px;
        }

        .divider-bottom {
            border-bottom: 5px solid #dc3545;
            margin-bottom: 40px;
        }

        .img-slider {
            max-height: 650px;
            object-fit: cover;
        }

        .dropdown .btn-lig {
            color: #212529;
            background-color: #343a40;
        }

        .dropdown .btn-light:hover {
            background-color: #f8f9fa;
        }

        .dropdown-menu .dropdown-item {
            color: #212529;
        }

        .dropdown-menu .dropdown-item:hover {
            background-color: #f8f9fa;
        }

        .cart-container {
            background-color: #343a40;
            padding: 20px;
            border-radius: 5px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            border-spacing: 0;
            background-color: transparent;
            margin-top: 20px;
        }

        th,
        td {
            padding: 15px;
            text-align: left;
            background-color: #343a40;
        }

        .quantity-button {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: #ccc;
            color: #000;
            text-align: center;
            line-height: 30px;
            cursor: pointer;
        }

        .quantity-button:hover {
            background-color: #aaa;
        }

        .delete-button {
            background-color: #dc3545;
            color: #fff;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
        }

        #total-price {
            text-align: right;
            margin-top: 20px;
            font-size: 18px;
        }

        #total-price-value {
            font-weight: bold;
        }
    </style>
</head>

<body>

    <!-- Ваша шапка профиля -->
    <header class="bg-dark text-white py-3">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-2">
                    <img src="logo.svg" alt="Логотип" class="img-fluid">
                </div>
                <div class="col-md-8 text-center">
                    <nav class="nav justify-content-center">
                        <a class="nav-link" href="index.php">Главная страница</a>
                        <a class="nav-link" href="product.php">Товары</a>
                        <a class="nav-link" href="about.php">О нас</a>
                    </nav>
                </div>
                <div class="col-md-2 text-right">
                    <?php
                    // Проверяем авторизацию пользователя
                    if (isset($_SESSION['auth']) && $_SESSION['auth'] === true) {
                        // Выводим круглую картинку вместо текста кнопки "Профиль"
                        echo '<div class="dropdown">
                                <button class="btn btn-light dropdown-toggle" type="button" id="profileDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img src="profile.png" alt="Иконка профиля" class="rounded-circle" style="width: 30px; height: 30px;">
                                </button>
                                <div class="dropdown-menu" aria-labelledby="profileDropdown">
                                    <a class="dropdown-item" href="#">Логин: ' . $_SESSION['login'] . '</a>
                                    <a class="dropdown-item" href="#">ФИО: ' . $_SESSION['fio'] . '</a>
                                    <a class="dropdown-item" href="#">Email: ' . $_SESSION['email'] . '</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="editProfile.php">Редактировать профиль</a>
                                    <a class="dropdown-item" href="changePassword.php">Изменить пароль</a>
                                    <a class="dropdown-item" href="deleteAccount.php">Удалить аккаунт</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="login.php">Выйти</a>
                                </div>
                            </div>';
                    } else {
                        // Выводим кнопку "Вход"
                        echo '<a href="login.php" class="btn btn-light">Вход</a>';
                    }
                    ?>
                </div>
            </div>
        </div>
    </header>

    <!-- Разделительная линия -->
    <div class="divider-top"></div>

    <!-- Контент страницы -->
    <div class="container cart-container">
        <h1 class="text-center">Ваша корзина</h1>

        <?php
        // Здесь будут строки с товарами из корзины
        if (mysqli_num_rows($result) > 0) {
            echo '<table>
                    <thead>
                        <tr>
                            <th>Товар</th>
                            <th>Цена</th>
                            <th>Количество</th>
                            <th>Сумма</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>';

            while ($row = mysqli_fetch_assoc($result)) {
                echo '<tr>
                        <td>' . $row['name'] . '</td>
                        <td>' . $row['price'] . ' руб.</td>
                        <td>' . $row['quantity'] . '</td>
                        <td>' . ($row['price'] * $row['quantity']) . ' руб.</td>
                        <td>Действия</td>
                    </tr>';
            }

            echo '</tbody></table>';
        } else {
            echo '<p>Нет товаров в корзине</p>';
        }
        ?>

        <!-- Информация о корзине -->
        <div id="total-price">
            Общая сумма: <span id="total-price-value">0</span> руб.
        </div>
    </div>

    <!-- Разделительная линия -->
    <div class="divider-bottom"></div>

    <!-- Ваш подвал страницы -->
    <footer class="footer mt-4 bg-dark text-white text-center py-2" style="height: 40px;">
        <p>&copy; 2024 Ваш сайт. Все права защищены.</p>
    </footer>

    <!-- Скрипты Bootstrap (необходимо добавить перед закрывающим тегом </body>) -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <!-- Ваши собственные скрипты JS, если есть -->
</body>

</html>
